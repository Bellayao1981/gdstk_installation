library.h
=========

.. literalinclude:: ../../include/gdstk/library.hpp
   :language: c++
   :start-after: namespace gdstk {
   :end-before: }  // namespace gdstk
