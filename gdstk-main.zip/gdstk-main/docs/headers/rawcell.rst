rawcell.h
=========

.. literalinclude:: ../../include/gdstk/rawcell.hpp
   :language: c++
   :start-after: namespace gdstk {
   :end-before: }  // namespace gdstk
