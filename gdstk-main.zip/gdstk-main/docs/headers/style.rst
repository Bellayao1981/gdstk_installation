style.h
=======

.. literalinclude:: ../../include/gdstk/style.hpp
   :language: c++
   :start-after: namespace gdstk {
   :end-before: }  // namespace gdstk
