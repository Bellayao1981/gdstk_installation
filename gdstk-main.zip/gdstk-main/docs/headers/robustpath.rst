robustpath.h
============

.. literalinclude:: ../../include/gdstk/robustpath.hpp
   :language: c++
   :start-after: namespace gdstk {
   :end-before: }  // namespace gdstk
