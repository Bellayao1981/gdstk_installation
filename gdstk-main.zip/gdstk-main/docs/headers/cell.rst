cell.h
======

.. literalinclude:: ../../include/gdstk/cell.hpp
   :language: c++
   :start-after: namespace gdstk {
   :end-before: }  // namespace gdstk
