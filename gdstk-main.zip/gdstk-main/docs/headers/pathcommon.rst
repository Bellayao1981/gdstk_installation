pathcommon.h
============

.. literalinclude:: ../../include/gdstk/pathcommon.hpp
   :language: c++
   :start-after: namespace gdstk {
   :end-before: }  // namespace gdstk
