gdsii.h
=======

.. literalinclude:: ../../include/gdstk/gdsii.hpp
   :language: c++
   :start-after: namespace gdstk {
   :end-before: }  // namespace gdstk
